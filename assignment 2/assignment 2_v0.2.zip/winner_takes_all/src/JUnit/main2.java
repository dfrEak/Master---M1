/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUnit;

import View.wta;
import View.xor;

/**
 *
 * @author d_frEak
 */
public class main2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

//        xor tes=new xor();
//        tes.setVisible(true);
        
        wta tes=new wta();
        tes.setVisible(true);
    }
    
}
